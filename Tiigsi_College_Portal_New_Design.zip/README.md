# Tiigsi College Portal — alternate design

A responsive college-style student portal built using plain HTML, CSS and JavaScript.

## Main areas
- Dashboard overview with student totals, completed/remaining exams, passed students, recent student records, and overall exam progress.
- Student directory: one dedicated area to view registered students, search by name/phone/emergency contact, filter by exam status, edit or delete records.
- Student registration: student details plus eight course marks out of 100.
- Exams & results: every student and every course with completed/remaining status.
- Reports & export: CSV report, JSON backup, and backup import.
- Settings: light mode, dark mode, follow device theme, academy name and campus settings.

## Open
Extract the ZIP and open `index.html` in a modern browser. Keep `index.html`, `style.css`, `script.js`, and the `assets` folder together.

## Data and hosting note
Records and preferences are stored in this browser on the current device. They are not automatically synchronized to other devices. This is a local prototype, not a deployed online college system. For multi-user access, user accounts, and shared student records, deploy it to a hosting service and connect a secure online database.

## Grade scale
A: 85–100; B: 75–84; C: 64–74; D: 50–63; F: below 50.
Average is calculated from entered marks. Overall result is pending until all eight exams are marked; after that, pass requires an average of at least 50.
