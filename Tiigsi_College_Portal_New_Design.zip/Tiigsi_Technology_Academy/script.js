(() => {
  "use strict";
  const KEY = "tiigsiAcademyStudents_v1";
  const courses = [
    "Introduction to Windows", "Microsoft Word", "Microsoft Excel",
    "Microsoft Access", "Microsoft PowerPoint", "Microsoft Publisher",
    "Microsoft Outlook", "Computer Literacy & Internet Training"
  ];
  const $ = (id) => document.getElementById(id);
  const form = $("studentForm");
  const marksGrid = $("marksGrid");
  let students = loadStudents();

  courses.forEach((course, index) => {
    const wrapper = document.createElement("div");
    wrapper.className = "mark-item";
    const label = document.createElement("label");
    label.htmlFor = `mark${index}`;
    label.textContent = course;
    const input = document.createElement("input");
    input.id = `mark${index}`;
    input.type = "number";
    input.min = "0";
    input.max = "100";
    input.step = "1";
    input.inputMode = "numeric";
    input.placeholder = "0–100";
    input.setAttribute("aria-label", `${course} mark out of 100`);
    input.addEventListener("input", updatePreview);
    wrapper.append(label, input);
    marksGrid.appendChild(wrapper);
  });

  function loadStudents() {
    try {
      const value = JSON.parse(localStorage.getItem(KEY) || "[]");
      return Array.isArray(value) ? value : [];
    } catch (error) {
      return [];
    }
  }
  function persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(students));
      return true;
    } catch (error) {
      alert("The browser could not save data. Please export a backup and check available browser storage.");
      return false;
    }
  }
  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
    })[ch]);
  }
  function getMarks() {
    return courses.map((_, i) => {
      const raw = $(`mark${i}`).value.trim();
      return raw === "" ? null : Number(raw);
    });
  }
  function gradeFor(average) {
    if (average === null || Number.isNaN(average)) return "—";
    if (average >= 85) return "A";
    if (average >= 74) return "B";
    if (average >= 64) return "C";
    if (average >= 50) return "D";
    return "F";
  }
  function resultFor(marks) {
    const entered = marks.filter(mark => mark !== null && Number.isFinite(mark));
    const average = entered.length ? entered.reduce((sum, n) => sum + n, 0) / entered.length : null;
    return { average, grade: gradeFor(average), passed: average !== null && average >= 50, entered: entered.length };
  }
  function updatePreview() {
    const marks = getMarks();
    const invalid = marks.some(mark => mark !== null && (!Number.isFinite(mark) || mark < 0 || mark > 100));
    const result = resultFor(marks);
    $("averagePreview").textContent = result.average === null ? "—" : result.average.toFixed(1);
    $("gradePreview").textContent = invalid ? "Check marks" : result.grade;
    $("statusPreview").textContent = invalid ? "Marks must be 0–100" : result.average === null ? "Enter course marks" : result.passed ? "Passed" : "Needs improvement";
  }
  function getFormRecord() {
    const marks = getMarks();
    if (marks.some(mark => mark !== null && (!Number.isFinite(mark) || mark < 0 || mark > 100))) {
      throw new Error("Every course mark must be a number from 0 to 100.");
    }
    const result = resultFor(marks);
    return {
      id: $("recordId").value || (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`),
      name: $("name").value.trim(),
      father: $("father").value.trim(),
      grandfather: $("grandfather").value.trim(),
      gender: $("gender").value,
      date: $("date").value,
      time: $("time").value,
      phone: $("phone").value.trim(),
      emergency: $("emergency").value.trim(),
      location: $("location").value.trim(),
      marks,
      average: result.average,
      grade: result.grade,
      passed: result.passed,
      updatedAt: new Date().toISOString()
    };
  }
  function render() {
    const query = $("searchInput").value.trim().toLocaleLowerCase();
    const filtered = students.filter(s => [s.name, s.phone, s.emergency].some(v => String(v || "").toLocaleLowerCase().includes(query)));
    $("studentRows").innerHTML = filtered.map(s => {
      const avg = typeof s.average === "number" ? s.average.toFixed(1) : "—";
      const grade = s.grade || "—";
      return `<tr>
        <td><strong>${escapeHTML(s.name)}</strong><small>${escapeHTML(s.gender || "")} · ${escapeHTML(s.date || "")}</small></td>
        <td class="phone-cell"><span>${escapeHTML(s.phone)}</span><span>${escapeHTML(s.emergency)}</span></td>
        <td><strong>${avg}%</strong></td>
        <td><span class="grade-chip ${s.passed ? "" : "fail"}">${escapeHTML(grade)}</span></td>
        <td><div class="actions"><button class="mini-btn" data-edit="${escapeHTML(s.id)}" type="button">Edit</button><button class="mini-btn delete" data-delete="${escapeHTML(s.id)}" type="button">Delete</button></div></td>
      </tr>`;
    }).join("");
    $("emptyState").style.display = filtered.length ? "none" : "block";
    if (students.length && !filtered.length) {
      $("emptyState").querySelector("strong").textContent = "No matching students";
      $("emptyState").querySelector("p").textContent = "Try a different name or phone number.";
    } else {
      $("emptyState").querySelector("strong").textContent = "No student records yet";
      $("emptyState").querySelector("p").textContent = "Register your first student using the form.";
    }
    $("totalStudents").textContent = students.length;
    $("passedStudents").textContent = students.filter(s => s.passed).length;
    const averages = students.filter(s => typeof s.average === "number").map(s => s.average);
    $("academyAverage").textContent = averages.length ? (averages.reduce((a,b)=>a+b,0)/averages.length).toFixed(1) : "—";
    $("recordCount").textContent = `${filtered.length} ${filtered.length === 1 ? "record" : "records"}`;
    $("showingCount").textContent = `Showing ${filtered.length} of ${students.length} students`;
  }
  function clearForm() {
    form.reset();
    $("recordId").value = "";
    $("formHeading").textContent = "Register a student";
    $("saveBtn").innerHTML = 'Save student record <span>→</span>';
    $("formMessage").textContent = "";
    $("date").value = new Date().toISOString().slice(0,10);
    $("time").value = new Date().toTimeString().slice(0,5);
    updatePreview();
  }
  function editStudent(id) {
    const s = students.find(item => item.id === id);
    if (!s) return;
    $("recordId").value = s.id;
    ["name","father","grandfather","gender","date","time","phone","emergency","location"].forEach(k => $(k).value = s[k] || "");
    courses.forEach((_, i) => $(`mark${i}`).value = s.marks?.[i] ?? "");
    $("formHeading").textContent = "Edit student record";
    $("saveBtn").innerHTML = 'Update student record <span>→</span>';
    $("formMessage").textContent = "Editing selected record.";
    updatePreview();
    window.scrollTo({top:0, behavior:"smooth"});
  }
  form.addEventListener("submit", event => {
    event.preventDefault();
    $("formMessage").textContent = "";
    try {
      const record = getFormRecord();
      if (!record.name || !record.father || !record.gender || !record.date || !record.phone || !record.emergency) {
        throw new Error("Please complete all required fields.");
      }
      const duplicate = students.find(s => s.phone === record.phone && s.id !== record.id && record.phone);
      if (duplicate && !confirm("Another record uses this phone number. Save anyway?")) return;
      const existingIndex = students.findIndex(s => s.id === record.id);
      if (existingIndex >= 0) students[existingIndex] = record;
      else students.unshift(record);
      if (!persist()) return;
      render();
      clearForm();
      $("formMessage").textContent = existingIndex >= 0 ? "Student record updated successfully." : "Student record saved successfully.";
    } catch (error) {
      $("formMessage").textContent = error.message;
      $("formMessage").style.color = "#bd3b42";
    }
  });
  $("resetBtn").addEventListener("click", () => setTimeout(clearForm, 0));
  $("searchInput").addEventListener("input", render);
  $("clearSearch").addEventListener("click", () => { $("searchInput").value = ""; render(); });
  $("studentRows").addEventListener("click", event => {
    const edit = event.target.closest("[data-edit]");
    const del = event.target.closest("[data-delete]");
    if (edit) editStudent(edit.dataset.edit);
    if (del) {
      const s = students.find(item => item.id === del.dataset.delete);
      if (s && confirm(`Delete the record for ${s.name}? This cannot be undone.`)) {
        students = students.filter(item => item.id !== s.id);
        if (persist()) { render(); if ($("recordId").value === s.id) clearForm(); }
      }
    }
  });
  function download(filename, content, type) {
    const blob = new Blob([content], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function csvCell(value) {
    if (Array.isArray(value)) value = value.map(v => v ?? "").join(" | ");
    return `"${String(value ?? "").replace(/"/g, '""')}"`;
  }
  $("exportBtn").addEventListener("click", () => {
    const headers = ["Name","Father's name","Grandfather's name","Gender","Date","Time","Phone number","Emergency contact","Location",...courses,"Average","General grade","Passed"];
    const rows = students.map(s => [s.name,s.father,s.grandfather,s.gender,s.date,s.time,s.phone,s.emergency,s.location,...courses.map((_,i)=>s.marks?.[i] ?? ""),s.average == null ? "" : s.average.toFixed(1),s.grade,s.passed ? "Yes" : "No"]);
    download("tiigsi-students.csv", "\uFEFF" + [headers,...rows].map(row=>row.map(csvCell).join(",")).join("\r\n"), "text/csv;charset=utf-8");
  });
  $("backupBtn").addEventListener("click", () => download("tiigsi-academy-backup.json", JSON.stringify({academy:"Tiigsi Technology Academy", exportedAt:new Date().toISOString(), students}, null, 2), "application/json"));
  $("importBtn").addEventListener("click", () => $("importFile").click());
  $("importFile").addEventListener("change", async event => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      const incoming = Array.isArray(parsed) ? parsed : parsed.students;
      if (!Array.isArray(incoming)) throw new Error("This file does not contain a student backup.");
      if (!confirm(`Import ${incoming.length} records? Existing records with the same ID will be replaced.`)) return;
      const map = new Map(students.map(s => [s.id, s]));
      incoming.forEach((s, i) => {
        if (!s || typeof s !== "object" || !s.name) return;
        const id = String(s.id || `import-${Date.now()}-${i}`);
        map.set(id, {...s, id});
      });
      students = Array.from(map.values());
      if (persist()) { render(); alert("Backup imported successfully."); }
    } catch (error) { alert(`Could not import backup: ${error.message}`); }
    finally { event.target.value = ""; }
  });
  $("year").textContent = new Date().getFullYear();
  clearForm();
  render();
})();