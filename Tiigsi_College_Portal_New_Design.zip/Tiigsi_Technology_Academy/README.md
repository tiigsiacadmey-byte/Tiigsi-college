# Tiigsi Technology Academy — Student Management Website

A responsive student registration and marks management website built with plain HTML, CSS, and JavaScript.

## Features
- Student name, father's name, grandfather's name, gender, date/time, phone, emergency contact, and location.
- Eight computer course marks, each out of 100.
- Automatic average, grade, and pass status.
- Search by student name, phone number, or emergency contact.
- Add, edit, delete, and list student records.
- Export student records to CSV and create/import JSON backups.
- Responsive layout for desktop, mobile phones, and iPad/tablets.
- Uses the supplied Tiigsi logo.

## How to open
1. Extract the ZIP file.
2. Keep `index.html`, `style.css`, `script.js`, and the `assets` folder together.
3. Open `index.html` in a modern browser.

## Important data note
This version saves records in the browser's local storage on the current device/browser. Records are **not automatically shared** with another phone, iPad, computer, or other staff member. Use **Backup data** regularly and store the downloaded JSON file somewhere safe. For a public website with shared, reliable records, connect a secure database and deploy it to a hosting service.

## Grade scale
- A: 85–100
- B: 74–84
- C: 64–73
- D: 50–63
- F: below 50

Overall status is Passed when the average of the entered marks is at least 50. Empty course marks are excluded from the average until entered.
